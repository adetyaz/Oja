 Code downloaded from html-form-guide.com
 This code may be used and distributed freely without any charge.

 Disclaimer
 ----------
 This file is provided "as is" with no expressed or implied warranty.
 The author accepts no liability if it causes any damage whatsoever.